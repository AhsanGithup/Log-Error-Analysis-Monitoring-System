import re
import pandas as pd
import tempfile


def clean_file(uploaded_file):

    pattern = r"""^(?P<domain>\S+)\s
    \[(?P<datetime>[^\]]+)\]\s
    \[(?P<level>[^\]]+)\]\s+
    (?:\[pid\s(?P<pid>\d+)\]\s)?                 
    (?P<module>[^\:]+):\s
    (?:\[client\s(?P<ip>\d+\.\d+\.\d+\.\d+):(?P<port>\d+)\]\s)?   
    (?P<code>AH\d+)?\:?\s*                      
    (?P<message>.*?)
    (?:\:\s(?P<path>/.*))?$                     
    """

    data = []

    # Convert uploaded file to text
    content = uploaded_file.read().decode("utf-8", errors="ignore")

    lines = content.splitlines()

    for line in lines:

        line = line.strip()

        match = re.match(pattern, line, re.VERBOSE)

        if match:
            data.append(match.groupdict())
        else:
            data.append({"raw_line": line})

    df = pd.DataFrame(data)

    # Cleaning
    if "datetime" in df.columns:
        df["datetime"] = pd.to_datetime(df["datetime"], errors="coerce")
        df["date"] = df["datetime"].dt.date

    if "port" in df.columns:
        df["port"] = pd.to_numeric(df["port"], errors="coerce")

    if "pid" in df.columns:
        df["pid"] = pd.to_numeric(df["pid"], errors="coerce")
    if "domain" in df.columns:
        df["domain"]=df["domain"].str.replace("atlashonda","abcdef")
    return df